package pe.demo.papayin

import android.app.Application
import org.koin.core.context.startKoin
import pe.demo.papayin.di.moviePresentationModule
import pe.demo.papayin.di.movieRepositoryModule
import pe.demo.papayin.remote.di.networkModule

class PDApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        startKoin {
            modules(moviePresentationModule, networkModule, movieRepositoryModule)
        }
    }
}