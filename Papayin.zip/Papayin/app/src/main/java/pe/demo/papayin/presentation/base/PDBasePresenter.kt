package pe.demo.papayin.presentation.base

interface PDBasePresenter<T> {
    var view: T
}