package pe.demo.papayin.domain.repository.movies

import io.reactivex.Single
import pe.demo.papayin.domain.model.PDMovie

interface PDMoviesRepository {
    fun getMovies(apiKey: String): Single<List<PDMovie>>
}