package pe.demo.papayin.ui.movies

import android.os.Bundle
import pe.demo.papayin.R
import pe.demo.papayin.ui.base.PDBaseActivity

class PDMoviesActivity : PDBaseActivity() {

    override fun getLayout(): Int {
        return R.layout.activity_movies
    }

    override fun setupView(savedInstanceState: Bundle?) {

    }

}
