package pe.demo.papayin.ui.splash

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.transition.ChangeBounds
import android.transition.TransitionManager
import android.view.View
import android.view.animation.AnimationUtils
import android.view.animation.AnticipateOvershootInterpolator
import androidx.constraintlayout.widget.ConstraintSet
import kotlinx.android.synthetic.main.activity_splash.*
import pe.demo.papayin.R
import pe.demo.papayin.ui.base.PDBaseActivity

class PDSplashActivity : PDBaseActivity() {

    val mHandler = Handler()

    override fun getLayout(): Int {
        return R.layout.activity_splash
    }

    override fun setupView(savedInstanceState: Bundle?) {
        mHandler.postDelayed({
            startLogoAnimation()
            fadeAnimation()
        }, 200)
    }

    @SuppressLint("NewApi")
    fun startLogoAnimation() {
        val mConstraintSet = ConstraintSet()
        mConstraintSet.clone(clSplash)
        mConstraintSet.setVerticalBias(R.id.ivMovieDb, 0.5f)
        val transition = ChangeBounds()
        transition.interpolator = AnticipateOvershootInterpolator(1.0f)
        transition.duration = 1000
        TransitionManager.beginDelayedTransition(clSplash, transition)
        mConstraintSet.applyTo(clSplash)
    }

    fun fadeAnimation() {
        ivMovieDb.visibility = View.VISIBLE
        ivMovieDb.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in))
    }

}
