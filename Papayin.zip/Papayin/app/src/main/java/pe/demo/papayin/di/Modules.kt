package pe.demo.papayin.di

import org.koin.core.qualifier.named
import org.koin.dsl.module
import pe.demo.papayin.data.contracts.movies.PDMoviesRemote
import pe.demo.papayin.data.repository.movies.PDMoviesDataRepository
import pe.demo.papayin.domain.executor.JobExecutor
import pe.demo.papayin.domain.executor.PostExecutionThread
import pe.demo.papayin.domain.executor.ThreadExecutor
import pe.demo.papayin.domain.interactor.movies.PDMoviesUseCase
import pe.demo.papayin.domain.repository.movies.PDMoviesRepository
import pe.demo.papayin.presentation.movies.PDMoviesContract
import pe.demo.papayin.presentation.movies.PDMoviesPresenter
import pe.demo.papayin.remote.mapper.movies.PDMoviesRemoteMapper
import pe.demo.papayin.remote.movies.PDMoviesRemoteImpl
import pe.demo.papayin.ui.UiThread

val moviePresentationModule = module {
    factory<PDMoviesContract.Presenter> { PDMoviesPresenter() }
}

val movieRepositoryModule = module {
    single<ThreadExecutor>(named("threadExecutor")) { JobExecutor() }
    single<PostExecutionThread>(named("postExecutionThread")) { UiThread() }

    single { PDMoviesRemoteMapper() }
    single<PDMoviesRemote> { PDMoviesRemoteImpl(get(), get()) }
    single<PDMoviesRepository>(named("movieRepository")) { PDMoviesDataRepository(get()) }

    factory {
        PDMoviesUseCase(
            get(named("postRepository")),
            get(named("threadExecutor")),
            get(named("postExecutionThread"))
        )
    }
}
