package pe.demo.papayin.ui.movies

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_movie.*
import pe.demo.papayin.domain.model.PDMovie
import pe.demo.papayin.remote.PDNetworkConstants

class PDMovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), LayoutContainer {

    override val containerView: View?
        get() = itemView

    fun bind(itemMovie: PDMovie) {
        tvTitle.text = itemMovie.title ?: ""
        tvGeners.text = itemMovie.genres ?: ""
        tvRate.text = itemMovie.duration.toString()
        tvRelease.text = itemMovie.releaseDate.toString()
        Glide.with(itemView.context).load(PDNetworkConstants.BASE_IMAGE_URL + itemMovie.posterImagePath)
            .apply(RequestOptions().fitCenter()).into(ivPoster)
    }
}