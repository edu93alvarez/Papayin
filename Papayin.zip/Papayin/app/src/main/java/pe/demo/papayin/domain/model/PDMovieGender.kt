package pe.demo.papayin.domain.model

data class PDMovieGender(
    var id: Int? = null,
    var gender: String? = null
)