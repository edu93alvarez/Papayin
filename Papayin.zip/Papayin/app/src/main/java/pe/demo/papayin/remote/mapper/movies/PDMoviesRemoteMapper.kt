package pe.demo.papayin.remote.mapper.movies

import pe.demo.papayin.domain.model.PDMovie
import pe.demo.papayin.remote.entities.movies.nowplaying.response.PDMovieData
import pe.demo.papayin.remote.entities.movies.nowplaying.response.PDMoviesResponse
import pe.demo.papayin.remote.mapper.PDRemoteMapper

class PDMoviesRemoteMapper : PDRemoteMapper<PDMoviesResponse, List<PDMovie>> {

    override fun mapToRemote(type: List<PDMovie>): PDMoviesResponse {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun mapFromRemote(response: PDMoviesResponse): List<PDMovie> {
        var movieList = mutableListOf<PDMovie>()
        response?.results?.let {
            for (movieData in it) {
                movieList.add(transformMovie(movieData))
            }
        }
        return movieList
    }

    fun transformMovie(movieData: PDMovieData): PDMovie {
        val movie = PDMovie()
        movie.title = movieData?.title ?: ""
        movie.posterImagePath = movieData?.poster_path ?: ""
        movie.genres = movieData?.genre_ids?.toMutableList()?.joinToString { ", " }
        movie.rating = movieData?.vote_average
        return movie
    }

}