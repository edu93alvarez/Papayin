package pe.demo.papayin.ui.moviedetail

import android.os.Bundle
import pe.demo.papayin.R
import pe.demo.papayin.ui.base.PDBaseActivity

class PDMovieDetailActivity : PDBaseActivity() {

    override fun getLayout(): Int {
        return R.layout.activity_movie_detail
    }

    override fun setupView(savedInstanceState: Bundle?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}
