package pe.demo.papayin.ui.movies

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import pe.demo.papayin.R
import pe.demo.papayin.domain.model.PDMovie

class PDMovieAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var mMovieList: List<PDMovie>? = null

    fun setDataList(movies: List<PDMovie>?) {
        this.mMovieList = movies
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val movieViewHolder: PDMovieViewHolder = holder as PDMovieViewHolder
        mMovieList?.get(position)?.let { movie -> movieViewHolder.bind(movie) }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater: LayoutInflater = LayoutInflater.from(parent.context)
        return PDMovieViewHolder(inflater.inflate(R.layout.item_movie, parent, true))
    }

    override fun getItemCount(): Int {
        return mMovieList?.size ?: 0
    }
}