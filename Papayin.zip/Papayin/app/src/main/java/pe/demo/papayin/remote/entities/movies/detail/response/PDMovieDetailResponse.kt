package pe.demo.papayin.remote.entities.movies.detail.response

import com.google.gson.annotations.SerializedName

class PDMovieDetailResponse(
    @SerializedName("id")
    var id: Int? = null,
    @SerializedName("genres")
    var genres: PDGenderData? = null,
    @SerializedName("poster_path")
    var poster_path: String? = null,
    @SerializedName("release_date")
    var release_date: String? = null,
    @SerializedName("original_title")
    var original_title: String? = null,
    @SerializedName("overview")
    var overview: String? = null,
    @SerializedName("production_countries")
    var production_countries: List<PDProductionCountryData>? = null,
    @SerializedName("production_companies")
    var production_companies: List<PDProductionCompanyData>? = null
)
