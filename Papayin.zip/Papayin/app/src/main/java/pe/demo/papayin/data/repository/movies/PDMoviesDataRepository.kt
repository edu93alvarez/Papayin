package pe.demo.papayin.data.repository.movies

import io.reactivex.Single
import org.koin.core.KoinComponent
import pe.demo.papayin.data.contracts.movies.PDMoviesRemote
import pe.demo.papayin.domain.model.PDMovie
import pe.demo.papayin.domain.repository.movies.PDMoviesRepository

class PDMoviesDataRepository(
    val movieRemote: PDMoviesRemote
) : PDMoviesRepository, KoinComponent {

    override fun getMovies(apiKey: String): Single<List<PDMovie>> {
        return movieRemote.getMovies(apiKey)
    }

}