package pe.demo.papayin.data.contracts.movies

import io.reactivex.Single
import pe.demo.papayin.domain.model.PDMovie

interface PDMoviesRemote {
    fun getMovies(apiKey: String): Single<List<PDMovie>>
}