package pe.demo.papayin.remote

class PDNetworkConstants {
    companion object {
        const val API_KEY_THE_MOVIE_DB = "752cd23fdb3336557bf3d8724e115570"
        const val BASE_API_URL = "https://api.themoviedb.org"
        const val URL_NOW_PLAYING_MOVIES = "/movie/now_playing"
        const val URL_MOVIE_DETAIL = "/movie/{movie_id}"
        const val URL_MOVIE_VIDEOS = "/movie/{movie_id}/videos"
        const val BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w200/"

    }
}